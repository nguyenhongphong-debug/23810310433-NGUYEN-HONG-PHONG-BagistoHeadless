# GraphQL Queries for Bagisto Headless

Dưới đây là các câu truy vấn GraphQL được yêu cầu trong Phần 2 của bài tập.

## Query 1: Lấy danh sách Categories
Lấy danh sách các danh mục sản phẩm bao gồm ID, tên và slug.

```graphql
query {
  categories {
    data {
      id
      name
      slug
    }
  }
}
```

## Query 2: Lấy danh sách 05 sản phẩm mới nhất
Lấy danh sách 5 sản phẩm mới nhất bao gồm ID, tên, giá, mô tả và url_key.

```graphql
query {
  products(first: 5, sort: "created_at-desc") {
    data {
      id
      name
      price
      description
      url_key
    }
  }
}
```

## Query 3: Lọc sản phẩm theo tên sinh viên (Nâng cao)
Sử dụng filters để lọc đúng 03 sản phẩm có tên chứa Họ tên của sinh viên (Ví dụ: "Nguyễn Hồng Phong").

```graphql
query {
  products(name: "Nguyễn Hồng Phong", first: 3) {
    data {
      id
      name
      price
      description
      url_key
    }
  }
}
```

> **Lưu ý:** Tên trường và cấu trúc có thể thay đổi tùy thuộc vào phiên bản của `bagisto/bagisto-headless`. Nếu bạn gặp lỗi, hãy kiểm tra Schema trong tab "Docs" của GraphQL Playground.
