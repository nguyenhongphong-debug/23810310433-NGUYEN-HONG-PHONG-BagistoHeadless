export interface Product {
  id: string;
  name: string;
  price: string;
  description: string;
  url_key: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface GraphQLResponse<T> {
  data: T;
  errors?: Array<{ message: string }>;
}
