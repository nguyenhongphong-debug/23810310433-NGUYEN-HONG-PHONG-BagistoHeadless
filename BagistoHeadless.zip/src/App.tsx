/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShoppingBag, Info, LayoutGrid, List, Search, User } from 'lucide-react';
import { Product } from './types';

// Mock data for the preview since we don't have a real Bagisto backend
const MOCK_PRODUCTS: Product[] = [
  {
    id: "1",
    name: "Sản phẩm 1 - Nguyễn Hồng Phong",
    price: "1500000",
    description: "Mô tả sản phẩm 1 chất lượng cao.",
    url_key: "san-pham-1"
  },
  {
    id: "2",
    name: "Sản phẩm 2 - Nguyễn Hồng Phong",
    price: "2500000",
    description: "Mô tả sản phẩm 2 với nhiều tính năng mới.",
    url_key: "san-pham-2"
  },
  {
    id: "3",
    name: "Sản phẩm 3 - Nguyễn Hồng Phong",
    price: "3500000",
    description: "Mô tả sản phẩm 3 phiên bản giới hạn.",
    url_key: "san-pham-3"
  },
  {
    id: "4",
    name: "Sản phẩm 4 - Mới nhất",
    price: "1200000",
    description: "Mô tả sản phẩm 4 giá cả phải chăng.",
    url_key: "san-pham-4"
  },
  {
    id: "5",
    name: "Sản phẩm 5 - Cao cấp",
    price: "5000000",
    description: "Mô tả sản phẩm 5 đẳng cấp sang trọng.",
    url_key: "san-pham-5"
  }
];

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Thông tin sinh viên
  const studentInfo = {
    name: "Nguyễn Hồng Phong",
    id: "23810310433"
  };

  /**
   * Hàm gọi API GraphQL để lấy danh sách sản phẩm
   * Query 2: Lấy danh sách 05 sản phẩm mới nhất
   */
  const fetchProducts = async () => {
    setLoading(true);
    try {
      // Trong môi trường thực tế, bạn sẽ gọi đến endpoint /graphql của Bagisto
      // const GRAPHQL_ENDPOINT = 'https://your-bagisto-domain.com/graphql';
      
      const query = `
        query {
          products(first: 5, sort: "created_at-desc") {
            data {
              id
              name
              price
              description
              url_key
            }
          }
        }
      `;

      // Giả lập gọi API (Sử dụng setTimeout để tạo hiệu ứng loading)
      // Trong thực tế: const response = await fetch(GRAPHQL_ENDPOINT, { method: 'POST', ... });
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Sử dụng dữ liệu mẫu cho bản xem trước
      setProducts(MOCK_PRODUCTS);
      setLoading(false);
    } catch (err) {
      console.error("Lỗi khi gọi API GraphQL:", err);
      setError("Không thể tải danh sách sản phẩm.");
      setLoading(false);
    }
  };

  useEffect(() => {
    // Dòng chữ định danh trong Console theo yêu cầu
    console.log(`%c[Định danh] ${studentInfo.name} - MSV: ${studentInfo.id}`, "color: #4f46e5; font-weight: bold; font-size: 14px;");
    fetchProducts();
  }, []);

  // Định dạng tiền tệ VNĐ
  const formatCurrency = (amount: string) => {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
    }).format(parseFloat(amount));
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900">
      {/* Header: Hiển thị Họ tên và MSSV */}
      <header className="sticky top-0 z-50 bg-white border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
              <ShoppingBag className="text-white w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold tracking-tight text-slate-900 hidden sm:block">
              Bagisto Headless
            </h1>
          </div>

          <div className="flex items-center gap-4 bg-indigo-50 px-4 py-2 rounded-full border border-indigo-100">
            <div className="flex flex-col items-end">
              <span className="text-sm font-bold text-indigo-700 uppercase tracking-wide">
                {studentInfo.name}
              </span>
              <span className="text-xs font-medium text-indigo-500">
                MSV: {studentInfo.id}
              </span>
            </div>
            <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white font-bold shadow-md">
              {studentInfo.name.charAt(0)}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Title Section */}
        <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight mb-2">
              Sản phẩm mới nhất
            </h2>
            <p className="text-slate-500 max-w-2xl">
              Danh sách 05 sản phẩm vừa được cập nhật từ hệ thống Bagisto Headless thông qua GraphQL API.
            </p>
          </div>
          
          <div className="flex items-center gap-2 bg-white p-1 rounded-lg border border-slate-200 shadow-sm">
            <button className="p-2 bg-indigo-50 text-indigo-600 rounded-md">
              <LayoutGrid size={20} />
            </button>
            <button className="p-2 text-slate-400 hover:text-slate-600">
              <List size={20} />
            </button>
          </div>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="bg-white rounded-2xl border border-slate-200 p-4 animate-pulse">
                <div className="aspect-square bg-slate-100 rounded-xl mb-4"></div>
                <div className="h-6 bg-slate-100 rounded w-3/4 mb-2"></div>
                <div className="h-4 bg-slate-100 rounded w-1/2 mb-6"></div>
                <div className="h-10 bg-slate-100 rounded w-full"></div>
              </div>
            ))}
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-6 py-4 rounded-xl flex items-center gap-3">
            <Info size={20} />
            <p>{error}</p>
          </div>
        )}

        {/* Product Grid: Cards */}
        {!loading && !error && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
          >
            <AnimatePresence>
              {products.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -8 }}
                  className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col"
                >
                  {/* Product Image Placeholder */}
                  <div className="aspect-square bg-slate-100 relative overflow-hidden">
                    <img 
                      src={`https://picsum.photos/seed/${product.id}/600/600`}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-white/90 backdrop-blur-sm text-indigo-600 text-[10px] font-bold px-2 py-1 rounded shadow-sm uppercase">
                        New Arrival
                      </span>
                    </div>
                  </div>

                  {/* Product Info */}
                  <div className="p-6 flex flex-col flex-grow">
                    <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-indigo-600 transition-colors line-clamp-1">
                      {product.name}
                    </h3>
                    <p className="text-slate-500 text-sm mb-4 line-clamp-2 flex-grow">
                      {product.description}
                    </p>
                    
                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-slate-100">
                      <div className="flex flex-col">
                        <span className="text-xs text-slate-400 font-medium">Giá bán</span>
                        <span className="text-xl font-extrabold text-indigo-600">
                          {formatCurrency(product.price)}
                        </span>
                      </div>
                      
                      <button className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl font-bold text-sm transition-colors shadow-lg shadow-indigo-200 flex items-center gap-2">
                        Chi tiết
                      </button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-600 p-1.5 rounded-md">
                <ShoppingBag className="text-white w-4 h-4" />
              </div>
              <span className="text-white font-bold tracking-tight">Bagisto Headless</span>
            </div>
            
            <div className="flex items-center gap-8 text-sm">
              <a href="#" className="hover:text-white transition-colors">Trang chủ</a>
              <a href="#" className="hover:text-white transition-colors">Sản phẩm</a>
              <a href="#" className="hover:text-white transition-colors">Liên hệ</a>
            </div>

            <div className="text-xs">
              © 2026 {studentInfo.name} - {studentInfo.id}. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
